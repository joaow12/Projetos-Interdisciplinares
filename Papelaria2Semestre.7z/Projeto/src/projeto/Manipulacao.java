package projeto;

public interface Manipulacao {
    
    boolean cadastro();
    
    String consulta();
}
