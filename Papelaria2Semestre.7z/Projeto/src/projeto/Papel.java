package projeto;

import javax.swing.JOptionPane;

public class Papel extends Produto implements Manipulacao {
    
    private String cor;
    private String tipo;
    private float largura;
    private float altura;
    private int gramatura;
    private boolean paltado;

    public Papel() {
        super(null, 0);
    }
    
    Papel(String c, String t, float l, float a, int g, boolean p, String m, float v){
        super(m, v);
        
        cor = c;
        tipo = t;
        largura = l;
        altura = a;
        gramatura = g;
        paltado = p;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public float getLargura() {
        return largura;
    }

    public void setLargura(float largura) {
        this.largura = largura;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    public int getGramatura() {
        return gramatura;
    }

    public void setGramatura(int gramatura) {
        this.gramatura = gramatura;
    }

    public boolean isPaltado() {
        return paltado;
    }

    public void setPaltado(boolean paltado) {
        this.paltado = paltado;
    }

    @Override
    public String getMarca() {
        return super.getMarca();
    }

    @Override
    public void setMarca(String marca) {
        super.setMarca(marca); 
    }

    @Override
    public void setValor(float valor) {
        super.setValor(valor);
    }

    @Override
    public String consulta() {
        return "\nPapel: " + "\nMarca: " + super.getMarca() + "\n" + "Valor: " + super.getValor() + "\n" + 
                "Cores: " + getCor() + "\n" + "Tipo: " + getTipo() + "\n" + "Largura: " + getLargura() + "\n" + "Altura: " + getAltura() + "\n" + "Gramatura: " + getGramatura() + "\n" + "Paltado: " + isPaltado() + "\n";
    }

    @Override
    public boolean cadastro() {
        setMarca(JOptionPane.showInputDialog("Digite a marca do Papel"));
        setValor(Integer.parseInt(JOptionPane.showInputDialog("Digite o valor do Papel")));
        setCor(JOptionPane.showInputDialog("Digite a cor do papel"));
        setTipo(JOptionPane.showInputDialog("Digite o tipo do papel"));
        setLargura(Float.parseFloat(JOptionPane.showInputDialog("Digite a largura do papel")));
        setAltura(Float.parseFloat(JOptionPane.showInputDialog("Digite a altura do papel")));
        setGramatura(Integer.parseInt(JOptionPane.showInputDialog("Digite a gramatura do papel")));
        String msg = (JOptionPane.showInputDialog("O papel é paltado?" + "\n" + "1 - Sim" + " 2 - Não"));
        setPaltado(msg.equals("1"));
        return true;
    }
    
    
}
