package projeto;
import javax.swing.JOptionPane;
public class CaixaLapis extends Produto implements Manipulacao {
    
    private int quantidade;
    private boolean colorido;
    
    public CaixaLapis() {
        super(null, 0);
    }
    
    CaixaLapis(int q, boolean c, String m, float v){
        super(m, v);
        colorido = c;
        quantidade = q;
    }    

    public boolean isColorido() {
        return colorido;
    }

    public void setColorido(boolean colorido) {
        this.colorido = colorido;
    }

    @Override
    public String getMarca() {
        return super.getMarca();
    }

    @Override
    public float getValor() {
        return super.getValor();
    }

    @Override
    public void setMarca(String marca) {
        super.setMarca(marca); 
    }

    @Override
    public void setValor(float valor) {
        super.setValor(valor); 
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    @Override
    public boolean cadastro() {
        setMarca(JOptionPane.showInputDialog("Digite a marca da Caixa de lapis"));
        setValor(Integer.parseInt(JOptionPane.showInputDialog("Digite o valor da caixa de lapis")));
        setQuantidade(Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de lapis que vem na caixa")));
        String msg = (JOptionPane.showInputDialog("A caixa de lapis é colorida? " + "\n" + "1 - Sim" + " 2 - Não"));
        setColorido(msg.equals("1"));
        return true;
    }

    @Override
    public String consulta() {
        return "\nCaixa de Lapis: " + "\nMarca: " + super.getMarca() + "\n" + "Valor: " + super.getValor() + "\n" + 
                "Quantidade: " + getQuantidade() + "\n" + "Colorido: " + isColorido() + "\n";
    }
    
    
    
}
