package projeto;
import java.util.ArrayList;
import javax.swing.JOptionPane;
public class Menu {

    public static void main(String[] args) {
        ArrayList <Pedido> p = new ArrayList();
        int opcao;
        do{
            JOptionPane.showMessageDialog(null,"Menu de seleção de função" + "\n" + "1: Cadastrar um novo pedido" + "\n" + "2: Consultar o pedido" + "\n" + 
                    "3: Listar todos os pedidos" + "\n" + "4: Encerrar o programa");
            opcao = Integer.parseInt(JOptionPane.showInputDialog("Digite a opção desejada"));
            switch (opcao){
                case 1:
                    Pedido a = new Pedido();
                    a.cadastro();
                    p.add(a);
                    break;
                case 2:
                    String op = JOptionPane.showInputDialog(null, "Digite o CPF do pedido que deseja consultar");
                    for(int i=0; i<p.size(); i++){
                        if(op.equals(p.get(i).getCliente().getCpf())){
                            JOptionPane.showMessageDialog(null, p.get(i).consulta());
                            System.out.println(p.get(i).consulta());
                            p.get(i).calculaTotalPedido();
                        }
                        else{
                            JOptionPane.showMessageDialog(null, "Pedido não encontrado");
                        }
                    }
                    break;
                case 3:
                    for(int i=0; i<p.size(); i++){
                        JOptionPane.showMessageDialog(null, "Pedido " + i + "\n" +  p.get(i).consulta());
                    }
                    break;
                case 4:
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida");
                    break;
            }
        }while (opcao!=4);{
        JOptionPane.showMessageDialog(null, "Programa encerrado");
    }
    }
    
}
