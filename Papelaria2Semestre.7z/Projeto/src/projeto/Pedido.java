package projeto;
import java.util.ArrayList;
import javax.swing.JOptionPane;
public class Pedido implements Manipulacao {
    
    private Data data = new Data(0, 0, 0);
    private Cliente cliente = new Cliente("", "", "");
    private float totalpedido;
    ArrayList <CaixaLapis> cl = new ArrayList();
    ArrayList <Papel> p = new ArrayList();
    ArrayList <Caderno> c = new ArrayList();

    public Pedido() {
        
    }

    public Pedido(Data data, Cliente cliente, float totalpedido) {
        this.data = data;
        this.cliente = cliente;
        this.totalpedido = totalpedido;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public float getTotalpedido() {
        return totalpedido;
    }

    public void setTotalpedido(float totalpedido) {
        this.totalpedido = totalpedido;
    }

    public ArrayList<CaixaLapis> getCl() {
        return cl;
    }

    public void setCl(ArrayList<CaixaLapis> cl) {
        this.cl = cl;
    }

    public ArrayList<Papel> getP() {
        return p;
    }

    public void setP(ArrayList<Papel> p) {
        this.p = p;
    }

    public ArrayList<Caderno> getC() {
        return c;
    }

    public void setC(ArrayList<Caderno> c) {
        this.c = c;
    }

    @Override
    public String consulta() {
        String msg = "Dados do pedido: " + "\n" + "\n" + "Data: " + getData().getDia() + "/" + getData().getMes() + "/" + getData().getAno() + "\n" + "Nome: " + getCliente().getNome() + "\nCPF: " + getCliente().getCpf() + "\nTelefone: " + getCliente().getTelefone() + "\n" + "Total do pedido: " + getTotalpedido() + "\n" + "\n" + 
                "Objetos no pedido: " + "\n";
        for (int i=0; i<c.size(); i++){
            msg += c.get(i).consulta();
        }
        for (int i=0; i<cl.size(); i++){
            msg += cl.get(i).consulta();
        }
        for (int i=0; i<p.size(); i++){
            msg += p.get(i).consulta();
        }
        return msg;
    }

    @Override
    public boolean cadastro() {
        getData().setDia(Integer.parseInt(JOptionPane.showInputDialog("Digite o dia do pedido")));
        getData().setMes(Integer.parseInt(JOptionPane.showInputDialog("Digite o mês do pedido")));
        getData().setAno(Integer.parseInt(JOptionPane.showInputDialog("Digite o ano do pedido")));
        getCliente().setNome(JOptionPane.showInputDialog("Digite o seu nome"));
        getCliente().setCpf(JOptionPane.showInputDialog("Digite o seu CPF"));
        getCliente().setTelefone(JOptionPane.showInputDialog("Digite o seu telefone"));
        int msg = 0;
        JOptionPane.showMessageDialog(null, "Menu de Seleção");
        while(msg != 4){
        JOptionPane.showMessageDialog(null, "1 - Cadastrar caderno" + "\n2 - Cadastrar papel" + 
                "\n3 - Cadastrar caixa de lapis" + "\n4 - Fechar pedido");
        msg = Integer.parseInt(JOptionPane.showInputDialog("Digite a opção desejada"));
        switch (msg){
            case 1:
                Caderno cad = new Caderno();
                cad.cadastro();
                c.add(cad);
                break;
            case 2:
                Papel pap = new Papel();
                pap.cadastro();
                p.add(pap);
                break;
            case 3:
                CaixaLapis cla = new CaixaLapis();
                cla.cadastro();
                cl.add(cla);
                break;
            default:
                JOptionPane.showMessageDialog(null, "Pedido Fechado");
        }
        }
        return true;
    }
    
    void calculaTotalPedido(){
        float aux = 0;
        for(int i=0; i<this.getC().size();i++){
            aux += this.getC().get(i).getValor();
        }
        for(int i=0; i<this.getCl().size();i++){
            aux += this.getCl().get(i).getValor();
        }
        for(int i=0; i<this.getP().size();i++){
            aux += this.getP().get(i).getValor();
        }
        setTotalpedido(aux+aux*(18/100));
        JOptionPane.showMessageDialog(null, "Valor final do pedido: R$" + getTotalpedido());
    }
    
    
    
    
}
