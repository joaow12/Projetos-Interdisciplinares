package projeto;

import javax.swing.JOptionPane;

public class Caderno extends Produto implements Manipulacao{
    
    private int qtdefolhas;
    private String tamanho;
    private String tipo;
    private boolean capadura;

    public Caderno() {
        super(null, 0);
    }
    
    
    Caderno (int q, String ta, String t, boolean c, String m, float v){
        super (m, v);
        qtdefolhas = q;
        tamanho = ta;
        tipo = t;
        capadura = c;
    }

    public int getQtdefolhas() {
        return qtdefolhas;
    }

    public void setQtdefolhas(int qtdefolhas) {
        this.qtdefolhas = qtdefolhas;
    }

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean isCapadura() {
        return capadura;
    }

    public void setCapadura(boolean capadura) {
        this.capadura = capadura;
    }

    @Override
    public String getMarca() {
        return super.getMarca();
    }

    @Override
    public void setMarca(String marca) {
        super.setMarca(marca);
    }

    @Override
    public void setValor(float valor) {
        super.setValor(valor);
    }

    @Override
    public float getValor() {
        return super.getValor();
    }

    @Override
    public String consulta() {
        return "\nCaderno" + "\nMarca: " + super.getMarca() + "\n" + "Valor: " + super.getValor() + 
                "\n" + "Quantidade de folhas: " + getQtdefolhas() + "\n" + "Tamanho: " + 
                getTamanho() + "\n" + "Tipo: " + getTipo() + "\n" + "Capadura: " + isCapadura() + "\n";
    }

    @Override
    public boolean cadastro() {
        setMarca(JOptionPane.showInputDialog("Digite a marca do caderno"));
        setValor(Float.parseFloat(JOptionPane.showInputDialog("Digite o valor do caderno")));
        setQtdefolhas(Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de folhas do papel")));
        setTamanho(JOptionPane.showInputDialog("Digite o tamanho do caderno"));
        setTipo(JOptionPane.showInputDialog("Digite o tipo de caderno"));
        String msg = (JOptionPane.showInputDialog("O caderno é capadura?" + "\n" + "1 - Sim" + " 2 - Não"));
        setCapadura(msg.equals("1"));
        return true;
    }
    
    
    
    
    
    
    
}
