/*
SQLyog Community v13.1.5  (64 bit)
MySQL - 10.4.11-MariaDB : Database - projinter
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`projinter` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `projinter`;

/*Table structure for table `tb_doencas` */

DROP TABLE IF EXISTS `tb_doencas`;

CREATE TABLE `tb_doencas` (
  `siglaDoenca` varchar(70) NOT NULL,
  `nomeDoenca` varchar(70) NOT NULL,
  `gravidade` decimal(1,0) NOT NULL,
  PRIMARY KEY (`siglaDoenca`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `tb_doencas` */

insert  into `tb_doencas`(`siglaDoenca`,`nomeDoenca`,`gravidade`) values 
('CBC','Carcinoma Basocelular',5),
('Covid','Coronavirus',5),
('DC','Doenças de Chagas',3),
('FA','Febre Amarela',3),
('H2N3','Gripe',2);

/*Table structure for table `tb_estados` */

DROP TABLE IF EXISTS `tb_estados`;

CREATE TABLE `tb_estados` (
  `siglaEstado` varchar(2) NOT NULL,
  `nomeEstado` varchar(70) NOT NULL,
  PRIMARY KEY (`siglaEstado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `tb_estados` */

insert  into `tb_estados`(`siglaEstado`,`nomeEstado`) values 
('MG','Minas Gerais'),
('MT','Mato Grosso'),
('RJ','Rio de Janeiro'),
('RS','Rio Grande do Sul'),
('SP','São Paulo');

/*Table structure for table `tb_paciente` */

DROP TABLE IF EXISTS `tb_paciente`;

CREATE TABLE `tb_paciente` (
  `CPF` decimal(11,0) NOT NULL,
  `nomePaciente` varchar(70) NOT NULL,
  `estadoResidencia` varchar(70) NOT NULL,
  `idade` decimal(3,0) NOT NULL,
  `sexo` char(1) NOT NULL,
  PRIMARY KEY (`CPF`),
  KEY `estadoResidencia` (`estadoResidencia`),
  CONSTRAINT `estadoResidencia` FOREIGN KEY (`estadoResidencia`) REFERENCES `tb_estados` (`siglaEstado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `tb_paciente` */

insert  into `tb_paciente`(`CPF`,`nomePaciente`,`estadoResidencia`,`idade`,`sexo`) values 
(17162324565,'Gabriela Sorato','RJ',25,'F'),
(23456456789,'Marquinhos Villas','MT',45,'M'),
(72673465789,'Joaozinho Villas','MG',28,'M'),
(82764564356,'Micaela Simmons','SP',19,'F'),
(85943543456,'João Barbosa','MT',75,'M'),
(87664345675,'Nicoli Simmons','RJ',45,'F'),
(92073567543,'Felipe Oliveira','RS',20,'M');

/*Table structure for table `tb_registrodoencas` */

DROP TABLE IF EXISTS `tb_registrodoencas`;

CREATE TABLE `tb_registrodoencas` (
  `CPF` decimal(11,0) NOT NULL,
  `siglaDoenca` varchar(70) NOT NULL,
  PRIMARY KEY (`CPF`),
  KEY `CPF` (`CPF`),
  KEY `siglaDoenca` (`siglaDoenca`),
  CONSTRAINT `tb_registrodoencas_ibfk_1` FOREIGN KEY (`siglaDoenca`) REFERENCES `tb_doencas` (`siglaDoenca`),
  CONSTRAINT `tb_registrodoencas_ibfk_2` FOREIGN KEY (`CPF`) REFERENCES `tb_paciente` (`CPF`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `tb_registrodoencas` */

insert  into `tb_registrodoencas`(`CPF`,`siglaDoenca`) values 
(82764564356,'CBC'),
(17162324565,'Covid'),
(85943543456,'Covid'),
(72673465789,'DC'),
(92073567543,'DC'),
(23456456789,'FA'),
(87664345675,'H2N3');

/*Table structure for table `tb_usuario` */

DROP TABLE IF EXISTS `tb_usuario`;

CREATE TABLE `tb_usuario` (
  `login` varchar(70) DEFAULT NULL,
  `senha` varchar(70) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `tb_usuario` */

insert  into `tb_usuario`(`login`,`senha`) values 
('Felipe','55655'),
('João','2231'),
('admin','admin');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
